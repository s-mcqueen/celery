# -*- coding: utf-8 -*-
"""Observer pattern."""
from __future__ import absolute_import, unicode_literals
from .signal import Signal

__all__ = ('Signal',)
